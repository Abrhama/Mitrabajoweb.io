function calcularPresupuesto() {
    var plazo = document.getElementById("plazoEntrega").value;
    var precio = parseInt(document.getElementById("Espadas").options[document.getElementById("Espadas").selectedIndex].getAttribute("data-precio"));
    var descuento = 0;
    var precioFinal = precio;
  
    if (plazo >= 30 && plazo < 62) {
      descuento = 5; 
    } else if (plazo >= 62 && plazo < 92) {
      descuento = 10; 
    } else if (plazo >= 92) {
      descuento = 15; 
    }
  
    if (document.getElementById("extra1").checked) {
      precioFinal += 10;
    }
    if (document.getElementById("extra2").checked) {
      precioFinal += 20;
    }
    if (document.getElementById("extra3").checked) {
      precioFinal += 30;
    }
  
    precioFinal -= precioFinal * (descuento / 100);
  
    document.getElementById("descuento").innerHTML = "Descuento aplicado: " + descuento + "%";
    document.getElementById("presupuesto").innerHTML = "Presupuesto: $" + precioFinal.toFixed(2);
  }
  
  function enviarFormulario() {
    var aceptarCondiciones = document.getElementById("aceptarCondiciones").checked;
    if (!aceptarCondiciones) {
      alert("Debes aceptar las condiciones de privacidad para enviar el formulario.");
      return;
    }
  
  
    alert("Formulario enviado correctamente.");
  }
  